/**
 * @author: ปริยวิศว์ เตชะกฤตเมธีธำรง 6510450593
 */

package pkg2;

import java.util.ArrayList;

public class Invoice {
    private ArrayList<Product> products;

    public Invoice() {
        products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public void displayInvoice() {
        System.out.println("\n\t\tI N V O I C E");
        System.out.println("Sam's Small Appliances");
        System.out.println("100 Main Street");
        System.out.println("Anytown, CA 98765\n");
        System.out.printf("%-20s%-10s%-5s%s%n", "Description", "Price", "Qty", "Subtotal");

        double total = 0;

        for (Product product : products) {
            total += product.getPrice() * product.getQty();
            System.out.printf("%-20s%-10.2f%-5d%.2f%n",
                    product.getName(), product.getPrice(), product.getQty(), product.getSubtotal());
        }

        System.out.printf("TOTAL TO PAY: $ %.2f%n", total);
    }
}
