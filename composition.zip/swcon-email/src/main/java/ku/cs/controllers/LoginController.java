package ku.cs.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import ku.cs.models.Current;
import ku.cs.services.FXRouter;

import java.io.IOException;

public class LoginController {
    @FXML private TextField usernameField;

    @FXML
    private void handleLogin() throws IOException {
        String username = usernameField.getText();
        Current.getInstance().setCurrentUser(username);
        FXRouter.goTo("send-email");
    }
}