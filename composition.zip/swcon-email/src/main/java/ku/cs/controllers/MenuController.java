package ku.cs.controllers;

import javafx.fxml.FXML;
import ku.cs.services.FXRouter;

import java.io.IOException;

public class MenuController {
    @FXML
    private void handleSendEmail() throws IOException {
        FXRouter.goTo("send-email");
    }

    @FXML
    private void handleReadEmail() throws IOException {
        FXRouter.goTo("read-email");
    }

    @FXML
    private void handleLogout() throws IOException {
        FXRouter.goTo("login");
    }
}
