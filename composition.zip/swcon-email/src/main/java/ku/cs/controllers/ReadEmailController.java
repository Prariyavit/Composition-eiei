package ku.cs.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import ku.cs.models.Current;
import ku.cs.models.Email;
import ku.cs.models.Inbox;
import ku.cs.services.EmailListFileDatasource;

import java.io.IOException;

public class ReadEmailController {
    @FXML private ListView<Email> emailListView;
    @FXML private BorderPane root;

    private EmailListFileDatasource emailListFileDatasource;
    private Inbox emailList;

    @FXML
    private void initialize() throws IOException {
        root.setLeft(FXMLLoader.load(getClass().getResource("/ku/cs/views/menu.fxml")));
        emailListFileDatasource = new EmailListFileDatasource("data", "email-list.csv");
        emailList = emailListFileDatasource.readData();

        showList(emailList);
    }

    private void showList(Inbox emailList) {
        emailListView.getItems().clear();
        String current = Current.getInstance().getCurrentUser();
        for (Email email : emailList.getEmailList()) {
            if (email.getSender().equals(current) || email.getRecipient().equals(current)) {
                emailListView.getItems().add(email);
            }
        }
    }

}
