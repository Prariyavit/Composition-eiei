package ku.cs.swconemail;

import javafx.application.Application;
import javafx.stage.Stage;
import ku.cs.services.FXRouter;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXRouter.bind(this, stage, "Email", 600, 400);
        configRoute();
        FXRouter.goTo("login");
    }

    private static void configRoute() {
        String resourcesPath = "ku/cs/views/";
        FXRouter.when("login", resourcesPath + "login.fxml");
        FXRouter.when("send-email", resourcesPath + "send-email.fxml");
        FXRouter.when("read-email", resourcesPath + "read-email.fxml");
    }

    public static void main(String[] args) {
        launch(args);
    }
}