package ku.cs.services;

import ku.cs.models.Email;
import ku.cs.models.Inbox;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class EmailListFileDatasource {
    private String directoryName;
    private String fileName;

    public EmailListFileDatasource(String directoryName, String fileName) {
        this.directoryName = directoryName;
        this.fileName = fileName;
        checkFileIsExisted(directoryName);
    }

    private void checkFileIsExisted(String directoryName) {
        File file = new File(directoryName);
        if (!file.exists()) {
            file.mkdirs();
        }
        String filePath = directoryName + File.separator + fileName;
        file = new File(filePath);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public Inbox readData() {
        Inbox emailList = new Inbox();
        String filePath = directoryName + File.separator + fileName;
        File file = new File(filePath);

        try (FileInputStream fileInputStream = new FileInputStream(file);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, StandardCharsets.UTF_8);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader)) {

            String line;

            while ((line = bufferedReader.readLine()) != null) {
                if (line.isEmpty()) continue;

                String[] data = line.split(",");

                String sender = data[0].trim();
                String recipient = data[1].trim();
                String text = data[2].trim();

                Email email = new Email(sender, recipient, text);
                emailList.addEmail(email);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return emailList;
    }

    public void writeData(Inbox data) {
        String filePath = directoryName + File.separator + fileName;
        File file = new File(filePath);

        try (OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8);
             BufferedWriter bufferedWriter = new BufferedWriter(writer)) {
            for (Email email : data.getEmailList()) {

                String line = email.getSender() + ","
                        + email.getRecipient() + ","
                        + email.getText();

                bufferedWriter.write(line);
                bufferedWriter.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
